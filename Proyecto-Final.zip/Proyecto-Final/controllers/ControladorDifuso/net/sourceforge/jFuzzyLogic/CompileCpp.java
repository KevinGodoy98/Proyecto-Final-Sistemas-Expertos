package net.sourceforge.jFuzzyLogic;

/**
 * Create C++ code
 * 
 * @author pcingola
 */
public interface CompileCpp {

	public String toStringCpp();
}
