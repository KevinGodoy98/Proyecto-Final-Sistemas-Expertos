/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.sourceforge.jFuzzyLogic.demo.dynamics;

import java.util.Vector;
import net.sourceforge.jFuzzyLogic.rule.Variable;


/**
 *
 * @author pjl
 */
public interface Model {


    public void update(double d);
   
}
