// File:          ControladorDifuso.java
// Date:
// Description:
// Author:
// Modifications:

// You may need to add other webots classes such as

import com.cyberbotics.webots.controller.DistanceSensor;
import com.cyberbotics.webots.controller.Motor;
import com.cyberbotics.webots.controller.Robot;
import com.cyberbotics.webots.controller.Camera;
import net.sourceforge.jFuzzyLogic.FIS;
import net.sourceforge.jFuzzyLogic.plot.JDialogFis;

// Here is the main class of your controller.
// This class defines how to initialize and how to run your controller.
public class ControladorDifuso{

  // This is the main function of your controller.
  // It creates an instance of your Robot instance and
  // it uses its function(s).
  // Note that only one instance of Robot should be created in
  // a controller program.
  // The arguments of the main function can be specified by the
  // "controllerArgs" field of the Robot node
  public static void main(String[] args) {

    // create the Robot instance.
    Robot robot = new Robot();

    // get the time step of the current world.
    int timeStep = (int) Math.round(robot.getBasicTimeStep());
    
    // Como acceder a los motores del Robot
     String nombresMotores[]= new String[]{"motordd","motordi","motorpd"
    ,"motorpi"};
    Motor motores[] = new Motor[nombresMotores.length];
    
    // Como hacer que los motores se queden en una posicion inicial
    for(int i=0;i<motores.length;i++){
      motores[i] = robot.getMotor(nombresMotores[i]);
      motores[i].setPosition(Double.POSITIVE_INFINITY);
      motores[i].setVelocity(5.0);
    }
    Camera camera = robot.getCamera("camera");
    camera.enable(timeStep);
    camera.recognitionEnable(timeStep);
    DistanceSensor sensori = robot.getDistanceSensor("sensori");
    DistanceSensor  sensord = robot.getDistanceSensor("sensord"); 
   
    sensori.enable(timeStep);
    sensord.enable(timeStep);  
       
    
    double di = 0.0;
    double dd = 0.0;
    
    // Si se requiere hacer una pausa de 1 segundo y ejecutar algun codigo
    robot.step(1000);
    System.out.println("Hola");
    
    
    
    // Ejemplo para que robot gire hacia la izquierda
    /*
    motores[0].setVelocity(-3.0);
    motores[1].setVelocity(-3.0);
    motores[2].setVelocity(3.0);
    motores[3].setVelocity(3.0);        
    */
    
    // CONTROL DIFUSO
    FIS _FIS = FIS.load("Controlador.fcl");
    _FIS.setVariable("distanciai",0.0);
    _FIS.setVariable("distanciad",0.0);    
    _FIS.evaluate();
    
    double vel = _FIS.getVariable("velocidad").getLatestDefuzzifiedValue();
    
    System.out.println("Vel: "+vel);
    
    JDialogFis dialogoF = new JDialogFis(_FIS);
    dialogoF.setVisible(true);

    // You should insert a getDevice-like function in order to get the
    // instance of a device of the robot. Something like:
    //  Motor motor = robot.getMotor("motorname");
    //  DistanceSensor ds = robot.getDistanceSensor("dsname");
    //  ds.enable(timeStep);

    // Main loop:
    // - perform simulation steps until Webots is stopping the controller
     int avoidObstacleCounter = 0;
    while (robot.step(timeStep) != -1) {
    
       double leftSpeed = 5.0;
         double rightSpeed = 5.0;
    
      // Read the sensors:
      // Enter here functions to read sensor data, like:
      //  double val = ds.getValue();

      // Process sensor data here.

      // Enter here functions to send actuator commands, like:
      //  motor.setPosition(10.0);
      
      di = sensori.getValue();
      dd = sensord.getValue();
      
     
     
      _FIS.setVariable("distanciai",di);
      _FIS.setVariable("distanciad",dd);    
      _FIS.evaluate();
      
      vel = _FIS.getVariable("velocidad").getLatestDefuzzifiedValue();
      System.out.println(di+"||"+dd+"||"+vel);
      dialogoF.repaint();
      
      
        
      for(int i=0;i<motores.length;i++){
        motores[i].setVelocity(vel);  
      }
 
  if (avoidObstacleCounter > 0) {
        avoidObstacleCounter--;
         leftSpeed = 3.0;
         rightSpeed = -3.0;
      } else { // read sensors
        for (int i = 0; i < 2; i++) {
         
          if (di < 99 || dd < 99)
            avoidObstacleCounter = 100;
        }
      }
      
      motores[0].setVelocity(leftSpeed);
      motores[1].setVelocity(rightSpeed);
      motores[2].setVelocity(leftSpeed);
      motores[3].setVelocity(rightSpeed);
    };
    

    // Enter here exit cleanup code.
  }
}
